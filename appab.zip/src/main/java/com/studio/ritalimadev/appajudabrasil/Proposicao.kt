package com.studio.ritalimadev.appajudabrasil

data class Proposicao (var id: Int,
                       var url: String,
                       var siglaTipo: String,
                       var ano: Int,
                       var ementa: String)
