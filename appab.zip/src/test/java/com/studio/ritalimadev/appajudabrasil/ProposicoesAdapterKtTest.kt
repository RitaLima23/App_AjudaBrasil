package com.studio.ritalimadev.appajudabrasil

import org.junit.Assert.*

class ProposicoesAdapterKtTest